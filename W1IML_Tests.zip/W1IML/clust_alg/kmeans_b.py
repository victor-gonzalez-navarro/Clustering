import numpy as np
import random
from eval_plot.evaluation import ploting_v

class Kmeans_b:
    labels_km = None

    # Constructor
    def __init__(self, num_clusters, num_tries_init, max_iterations):
        self.num_clusters = num_clusters
        self.num_tries_init = num_tries_init
        self.max_iterations = max_iterations

    def _euclidean_distance(self, a, b):
        return np.sqrt(sum([(xi - xj) ** 2 for xi, xj in zip(a, b)]))


    def _choose_init_points(self, n_points, points):
        idxs = []
        init_points = []
        for i in range(n_points):
            idx = random.randrange(len(points))
            while (idx in idxs):
                idx = random.randrange(len(points))
            idxs.append(idx)
            init_points.append(points[idx])
        return np.array(init_points)


    def _has_converged(self, prev, curr):
        return sum(abs(np.subtract(prev, curr))) == 0


    def _new_centroid(self, points):
        return np.mean(points, 0)


    def _cluster(self, points, centroids):
        labels = np.zeros([points.shape[0], 1])
        total_sse = np.zeros([len(centroids), 1])

        for i in range(points.shape[0]):
            min_dist = 0
            min_idx = -1
            for j in range(len(centroids)):
                curr_dist = self._euclidean_distance(points[i], centroids[j])
                if (curr_dist < min_dist or min_idx == -1):
                    min_dist = curr_dist
                    min_idx = j

            labels[i] = min_idx
            total_sse[min_idx] += min_dist ** 2

        for label in np.unique(labels):
            centroids[int(label)] = points[np.where(labels == label)[0], :].mean(axis=0)

        return labels, total_sse, centroids


    def kmeans_algorithm(self, data, result_sse, result_labels):
        converged = False
        labels = np.zeros([data.shape[0], 1])
        centroids = self._choose_init_points(self.num_clusters, data)

        while (not converged):
            prev_counts = np.unique(labels, return_counts=True)
            labels, total_see, centroids = self._cluster(data, centroids)
            post_counts = np.unique(labels, return_counts=True)
            if (self._has_converged(prev_counts[1], post_counts[1])):
                converged = True

        result_labels.append(labels)
        result_sse.append(np.sum(total_see))

        return result_sse, result_labels

    def fit(self, data):
        print('\n' + '\033[1m' + 'Computing clusters with K-Means algorithm...' + '\033[0m')

        result_labels = []
        result_sse = []

        # Compute kmeans for different initializations of the clusters
        for nm in range(0, self.num_tries_init):
            result_sse, result_labels = self.kmeans_algorithm(data, result_sse, result_labels)

        print('\033[1m' + 'Accuracy with initalization: ' + str(np.argmin(result_sse)) + ' (the best one)' + '\033[0m')
        self.labels_km = np.array(result_labels[np.argmin(result_sse)])
        print('The SSE (sum of squared errors) is: ' + '\033[1m' + '\033[94m' + str(round(min(result_sse),
                                                                                          2)) + '\033[0m')

        #ploting_v(data, self.num_clusters, self.labels_km)

